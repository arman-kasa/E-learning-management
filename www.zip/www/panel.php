<?php require_once 'header.php'; ?>

<?php
if (!isset($_COOKIE["type"])){
    echo "<script>alert('لطفا ابتدا وارد حساب خود شوید')</script>";
    header("location: login.php");
    exit();
}
$user_courses = "";
if ($_COOKIE["type"] == 0) {
    $username = $_COOKIE["id"];
    $user_courses = $conn->query("SELECT * FROM classrooms WHERE student_no = $username")->fetch_all(MYSQLI_ASSOC);
} else {
    $username = $_COOKIE["id"];
    $user_courses = $conn->query("SELECT * FROM courses WHERE professor_no = $username")->fetch_all(MYSQLI_ASSOC);
}
?>
<div class="container text-center">
    <table style="margin: auto" class="table  text-center table-striped mt-5 w-75">
        <thead>
        <tr>
            <th scope="col">درس</th>
            <th scope="col">استاد</th>
        </tr>
        </thead>
        <tbody>
        <?php if ($_COOKIE["type"] == 0): ?>
            <?php foreach ($user_courses as $course) {
                $cid = $course["course_id"];
                $course_name = $conn->query("SELECT * FROM courses WHERE course_id = $cid")->fetch_assoc();
                $pro_no = $course_name["professor_no"];
                $pro = $conn->query("SELECT name_fa FROM faculty WHERE professor_no = $pro_no")->fetch_assoc();


                ?>
                <tr>
                    <td><?= $course_name["course_name"] ?></td>
                    <td><?=$pro["name_fa"]?></td>
                </tr>
            <?php } else: ?>
            <?php foreach ($user_courses as $course) {
                ?>
                <tr>
                    <td><?= $course["course_name"] ?></td>
                    <td>شما</td>
                </tr>
            <?php } ?>

        <?php endif; ?>
        </tbody>
    </table>

    <button type="button" class="btn btn-danger mt-5" onclick="logout()">خروج از حساب کاربری</button>

</div>
<script>
    function logout(){
        document.cookie = "type" + '=; Max-Age=0';
        document.cookie = "id" + '=; Max-Age=0';
        document.location = "panel.php";
    }
</script>
<?php require_once 'footer.php'; ?>
