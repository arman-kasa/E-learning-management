<?php
require_once ('config.php');
$data = $conn->query("SELECT * FROM students");
$data = $data->fetch_all(MYSQLI_ASSOC);
foreach ($data as $stu){
    $myArray = explode(' - ', $stu["name_en"]);
    $id = $stu["student_no"];
    $pass = $stu["national_code"] . substr($myArray[0] , 0 , 1)  .  substr($myArray[1] , 0 , 1) ;
    $email = substr($myArray[0] , 0 , 1) . '.' . $myArray[1] . "@aut.ac.ir";
    $hash = MD5($pass);
    $conn->query("UPDATE students SET email = '$email' ,password = '$hash' WHERE student_no = $id");
}

$data = $conn->query("SELECT * FROM faculty");
$data = $data->fetch_all(MYSQLI_ASSOC);
foreach ($data as $stu){
    $myArray = explode(' - ', $stu["name_en"]);
    $id = $stu["professor_no"];
    $pass = $stu["national_code"] . substr($myArray[0] , 0 , 1)  .  substr($myArray[1] , 0 , 1) ;
    $email = substr($myArray[0] , 0 , 1) . '.' . $myArray[1] . "@aut.ac.ir";
    $hash = MD5($pass);
    $conn->query("UPDATE faculty SET email = '$email' ,password = '$hash' WHERE professor_no = $id");
}
