<?php require_once 'header.php'; ?>
<?php

if (isset($_POST['login'])) {

    $username = $_POST["username"];
    if ($_POST["type"] == 0) {
        $user = $conn->query("SELECT * FROM students WHERE student_no = '$username'");
        if ($user->num_rows > 0) {
            $user = $user->fetch_assoc();
            if (md5($_POST["password"]) == $user["password"]) {
                setcookie("id", $_POST["username"]);
                setcookie("type", "0");
                header("location: panel.php");
                exit();
            } else {
                echo "<script>alert('پسورد اشتباه است')</script>";
            }
        } else {
            echo "<script>alert('نام کاربری اشتباه است')</script>";
        }

    } else {
        $user = $conn->query("SELECT * FROM faculty WHERE professor_no = '$username'");
        if ($user->num_rows > 0) {
            $user = $user->fetch_assoc();
            if (md5($_POST["password"]) == $user["password"]) {
                setcookie("id", $_POST["username"]);
                setcookie("type", "1");
                header("location: panel.php");
                exit();

            } else {
                echo "<script>alert('پسورد اشتباه است')</script>";
            }

        } else {
            echo "<script>alert('نام کاربری اشتباه است')</script>";
        }

    }
}
?>
<div class="container w-25 mt-5">
    <form action="" method="post">
        <!-- Email input -->
        <div class="form-outline mb-4">
            <input type="username" name="username" id="form2Example1" class="form-control"/>
            <label class="form-label" for="form2Example1">نام کاربری</label>
        </div>

        <!-- Password input -->
        <div class="form-outline mb-4">
            <input type="password" name="password" id="form2Example2" class="form-control"/>
            <label class="form-label" for="form2Example2">رمز ورود</label>
        </div>
        <div class="form-outline mb-4 w-100">
            <select class="select-input" name="type" id="">
                <option value="0">داشنجو</option>
                <option value="1">استاد</option>
            </select>
        </div>


        <button type="submit" name="login" class="btn btn-primary btn-block mb-4">ورود</button>


    </form>
</div>

<?php require_once 'footer.php'; ?>
